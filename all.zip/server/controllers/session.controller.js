// controllers/session.controller.js
export const userSession = async (req, res) => {
  console.log('Vérification de la session utilisateur:', req.session);
  if (req.session.user && req.session.user.status === "ready") {
    return res.status(200).json({ firstname: req.session.user.firstname });
  } else {
    return res.status(401).json({ error: "Vous n'êtes pas connecté" });
  }
};
