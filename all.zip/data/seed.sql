INSERT INTO "question" ("question", "answer1", "answer2", "answer3", "answer4", "good_answer", "difficulty")
VALUES
('What is the capital of France?', 'Paris', 'London', 'Berlin', 'Madrid', 'Paris', 'easy'),
('What is the capital of Germany?', 'Paris', 'London', 'Berlin', 'Madrid', 'Berlin', 'easy');




